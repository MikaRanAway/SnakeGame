package snake.src.main.java.snake;

import java.awt.*;

public class UniversalColor {
    static Color colorHead = Color.decode("#00ff00");
    static Color colorBody = Color.decode("#00dd00");

public void setColorHead(Color head, Color body) {
    colorHead = head;
    colorBody = body;
    }
}


