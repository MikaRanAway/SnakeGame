package snake.src.main.java.snake;

import snake.src.main.java.snake.components.WelcomeFrame;

public final class Main{
    public static void main(String[] args) {
        System.out.println("~~~~<  *");
        WelcomeFrame snakeGame= new WelcomeFrame();
        //Game game = new Game();
        //game.start();
    }

}